def judge(password):
    """
    判断密码强度

    参数:
    password -- 密码字符串

    返回:
    密码强度等级 (0-4级)
    """
    # 初始化强度等级
    level = 0

    # 检查密码是否只包含数字和字母
    if not password.isalnum():
        return -1  # 包含非法字符

    # 检查条件1: 是否有数字
    has_digit = any(char.isdigit() for char in password)
    if has_digit:
        level += 1

    # 检查条件2: 是否有大写字母
    has_upper = any(char.isupper() for char in password)
    if has_upper:
        level += 1

    # 检查条件3: 是否有小写字母
    has_lower = any(char.islower() for char in password)
    if has_lower:
        level += 1

    # 检查条件4: 位数是否不少于8位
    if len(password) >= 8:
        level += 1

    return level


def get_strength_description(level):
    """
    根据强度等级返回描述

    参数:
    level -- 密码强度等级

    返回:
    强度描述字符串
    """
    descriptions = {
        0: "极弱密码",
        1: "弱密码",
        2: "中等密码",
        3: "强密码",
        4: "极强密码"
    }
    return descriptions.get(level, "未知强度")


# 主程序
if __name__ == "__main__":
    print("密码强度检测程序")
    print("=" * 40)
    print("密码只能由数字与字母组成")
    print("强度判断标准：")
    print("1. 有数字")
    print("2. 有大写字母")
    print("3. 有小写字母")
    print("4. 位数不少于8位")
    print("每满足一条，强度增加一级")
    print()

    while True:
        password = input("请输入测试密码（输入 'q' 退出）: ")

        if password.lower() == 'q':
            print("程序已退出！")
            break

        # 检查密码是否只包含数字和字母
        if not password.isalnum():
            print("错误：密码只能由数字与字母组成！")
            continue

        # 判断密码强度
        strength_level = judge(password)

        # 输出结果
        if strength_level >= 0:
            description = get_strength_description(strength_level)
            print(f"{password}的密码强度为{strength_level}级 ({description})")

            # 详细分析
            print("详细分析：")
            has_digit = any(char.isdigit() for char in password)
            has_upper = any(char.isupper() for char in password)
            has_lower = any(char.islower() for char in password)
            length_ok = len(password) >= 8

            conditions = [
                ("包含数字", has_digit),
                ("包含大写字母", has_upper),
                ("包含小写字母", has_lower),
                ("长度≥8位", length_ok)
            ]

            for condition, met in conditions:
                status = "✓" if met else "✗"
                print(f"  {status} {condition}")
        else:
            print("密码包含非法字符！")

        print()


# 测试函数
def run_tests():
    """
    运行预定义的测试用例
    """
    print("\n" + "=" * 40)
    print("预定义测试用例：")
    print("-" * 40)

    test_cases = [
        "abc123",  # 预期: 2级 (有数字,有小写字母)
        "Abc123",  # 预期: 3级 (有数字,有大写字母,有小写字母)
        "Abc12345",  # 预期: 4级 (满足所有条件)
        "123456",  # 预期: 1级 (只有数字)
        "ABCDEF",  # 预期: 1级 (只有大写字母)
        "abcdef",  # 预期: 1级 (只有小写字母)
        "AbCdEf",  # 预期: 2级 (有大写字母,有小写字母)
        "12345678",  # 预期: 2级 (有数字,长度≥8位)
        "a"  # 预期: 1级 (只有小写字母)
    ]

    for password in test_cases:
        level = judge(password)
        description = get_strength_description(level)
        print(f"{password:12} -> 强度{level}级 ({description})")


# 运行测试
run_tests()