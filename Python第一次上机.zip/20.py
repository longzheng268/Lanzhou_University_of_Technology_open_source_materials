def m(i):
    """
    递归计算级数：m(i) = 1/3 + 2/5 + 3/7 + 4/9 + ... + i/(2i+1)

    参数:
    i -- 级数的项数

    返回:
    级数的前i项和
    """
    # 基本情况：当i=1时，返回第一项
    if i == 1:
        return 1 / 3
    # 递归情况：前i-1项的和加上第i项
    else:
        return m(i - 1) + i / (2 * i + 1)


def m_iterative(i):
    """
    使用迭代方法计算级数，用于验证递归结果

    参数:
    i -- 级数的项数

    返回:
    级数的前i项和
    """
    total = 0
    for n in range(1, i + 1):
        total += n / (2 * n + 1)
    return total


def display_series(i):
    """
    显示级数的展开形式

    参数:
    i -- 级数的项数
    """
    terms = []
    for n in range(1, i + 1):
        terms.append(f"{n}/{2 * n + 1}")
    return " + ".join(terms)


# 主程序
if __name__ == "__main__":
    print("级数计算程序")
    print("计算级数: m(i) = 1/3 + 2/5 + 3/7 + 4/9 + ... + i/(2i+1)")
    print("=" * 50)

    # 测试不同的i值
    test_values = [1, 2, 3, 5, 10, 20]

    print("递归方法计算结果:")
    print("-" * 30)
    for i in test_values:
        recursive_result = m(i)
        iterative_result = m_iterative(i)
        series = display_series(i)

        print(f"m({i}) = {series}")
        print(f"     = {recursive_result:.6f} (递归)")
        print(f"     = {iterative_result:.6f} (迭代)")
        print(f"     两种方法结果一致: {abs(recursive_result - iterative_result) < 1e-10}")
        print()

    # 交互式测试
    print("=" * 50)
    print("交互式测试:")

    while True:
        try:
            user_input = input("\n请输入i的值 (输入 'q' 退出): ")

            if user_input.lower() == 'q':
                print("程序已退出!")
                break

            i = int(user_input)

            if i <= 0:
                print("请输入一个正整数!")
                continue

            if i > 50:
                print("注意: i值较大，递归可能较慢，建议使用迭代方法")
                continue

            recursive_result = m(i)
            iterative_result = m_iterative(i)
            series = display_series(i) if i <= 10 else f"1/3 + 2/5 + ... + {i}/{2 * i + 1}"

            print(f"m({i}) = {series}")
            print(f"     = {recursive_result:.8f}")

            # 显示前几项的具体值（如果i不太大）
            if i <= 10:
                print("\n各项的值:")
                partial_sum = 0
                for n in range(1, i + 1):
                    term = n / (2 * n + 1)
                    partial_sum += term
                    print(f"  第{n}项: {n}/{2 * n + 1} = {term:.6f}, 部分和 = {partial_sum:.6f}")

        except ValueError:
            print("输入无效，请输入一个整数!")
        except RecursionError:
            print("递归深度过大，请使用迭代方法!")


# 性能比较
def performance_comparison():
    """
    比较递归和迭代方法的性能
    """
    import time

    print("\n" + "=" * 50)
    print("性能比较 (i=30):")

    # 递归方法
    start_time = time.time()
    recursive_result = m(30)
    recursive_time = time.time() - start_time

    # 迭代方法
    start_time = time.time()
    iterative_result = m_iterative(30)
    iterative_time = time.time() - start_time

    print(f"递归方法: 结果 = {recursive_result:.8f}, 时间 = {recursive_time:.6f}秒")
    print(f"迭代方法: 结果 = {iterative_result:.8f}, 时间 = {iterative_time:.6f}秒")
    print(f"递归/迭代时间比: {recursive_time / iterative_time:.2f}")


# 运行性能比较
performance_comparison()