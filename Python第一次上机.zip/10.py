total = sum(i * (i + 1) * (i + 2) for i in range(1, 50, 2))
print(f"数列的和为：{total}")