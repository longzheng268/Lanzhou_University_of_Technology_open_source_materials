import random
import math

# 产生两个0~100之间的随机整数
RND1 = random.randint(0, 100)
RND2 = random.randint(0, 100)

print(f"随机数 RND1 = {RND1}")
print(f"随机数 RND2 = {RND2}")

# 使用math.gcd()计算最大公约数
gcd_value = math.gcd(RND1, RND2)
print(f"最大公约数：{gcd_value}")

# 计算最小公倍数
# 注意：如果其中一个数为0，则最小公倍数为0
if RND1 == 0 or RND2 == 0:
    lcm_value = 0
else:
    lcm_value = abs(RND1 * RND2) // gcd_value

print(f"最小公倍数：{lcm_value}")