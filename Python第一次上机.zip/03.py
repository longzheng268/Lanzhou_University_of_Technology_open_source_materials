# 初始武力值
initial_power = 1

# 一年天数
days = 365

# 计算天天向上的武力值（每天增加1%）
power_up = initial_power * (1.01 ** days)

# 计算天天向下的武力值（每天减少1%）
power_down = initial_power * (0.99 ** days)

# 输出结果
print("天天向上一年后的武力值：", power_up)
print("天天向下一年后的武力值：", power_down)