import jieba
import jieba.posseg as pseg


# （1）使用jieba库对评论进行分词，提取所有的形容词、副词以及连词
def extract_words(comment):
    """提取形容词、副词和连词"""
    words = pseg.cut(comment)

    adjectives = []  # 形容词
    adverbs = []  # 副词
    conjunctions = []  # 连词

    for word, flag in words:
        if flag.startswith('a'):  # 形容词
            adjectives.append(word)
        elif flag.startswith('d'):  # 副词
            adverbs.append(word)
        elif flag == 'c':  # 连词
            conjunctions.append(word)

    return adjectives, adverbs, conjunctions


# （2）计算产品评论的情感分
def calculate_sentiment_score(comment, degree_dict):
    """计算评论的情感分"""
    # 褒义词和贬义词词典
    positive_words = {'好': 1, '不错': 1}
    negative_words = {'糟糕': -1, '不方便': -1}

    words = pseg.cut(comment)
    word_list = list(words)

    total_score = 0

    # 遍历分词结果
    i = 0
    while i < len(word_list):
        word, flag = word_list[i]

        # 检查是否是程度副词
        if word in degree_dict and flag.startswith('d'):
            degree_weight = degree_dict[word]

            # 检查下一个词是否是形容词
            if i + 1 < len(word_list):
                next_word, next_flag = word_list[i + 1]

                # 如果是褒义词
                if next_word in positive_words:
                    score = positive_words[next_word] * degree_weight
                    total_score += score
                    i += 1  # 跳过下一个词，因为它已经被处理
                # 如果是贬义词
                elif next_word in negative_words:
                    score = negative_words[next_word] * degree_weight
                    total_score += score
                    i += 1  # 跳过下一个词，因为它已经被处理

        # 检查单独的褒义词或贬义词（没有程度副词修饰）
        elif word in positive_words:
            total_score += positive_words[word]
        elif word in negative_words:
            total_score += negative_words[word]

        i += 1

    return total_score


# 主程序
def main():
    # 用户评论
    s = "外观很好，画质也不错。但是音质真的太糟糕了！操作也不方便。"

    print("用户评论:", s)
    print()

    # （1）提取形容词、副词和连词
    adjectives, adverbs, conjunctions = extract_words(s)

    print("（1）提取结果:")
    print("形容词:", adjectives)
    print("副词:", adverbs)
    print("连词:", conjunctions)
    print()

    # （2）计算情感分
    degree_dict = {"很": 2, "大": 3, "非常": 2, "较": 1, "极": 3, "无比": 4}

    sentiment_score = calculate_sentiment_score(s, degree_dict)

    print("（2）情感分析结果:")
    print(f"情感分: {sentiment_score}")

    if sentiment_score > 0:
        print("情感倾向: 积极")
    elif sentiment_score < 0:
        print("情感倾向: 消极")
    else:
        print("情感倾向: 中性")


# 运行主程序
if __name__ == "__main__":
    main()