# 输入百分制分数
score = float(input("请输入百分制分数："))

# 判断分数范围并转换为等级制
if score >= 90:
    grade = "优"
elif score >= 80:
    grade = "良"
elif score >= 70:
    grade = "中"
elif score >= 60:
    grade = "及格"
else:
    grade = "不及格"

# 输出结果
print(f"分数 {score} 对应的等级是：{grade}")