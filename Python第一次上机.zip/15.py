# （1）使用字典存放产品信息，产品名称作为键，价格作为值
myDict = {
    "方糖": 99,
    "X1": 499,
    "魔盒": 399,
    "曲奇": 299
}

# （2）输出所有在售产品的价目表
print("在售产品价目表：")
print("-" * 20)
for product, price in myDict.items():
    print(f"{product}……{price}元")

# （3）输出所有产品的平均价格
total_price = sum(myDict.values())
average_price = total_price / len(myDict)
print(f"\n所有产品的平均价格：{average_price:.2f}元")

# （4）输出价格最高的产品名称
max_price = max(myDict.values())
# 找出价格等于最高价格的所有产品
most_expensive_products = [product for product, price in myDict.items() if price == max_price]

print(f"\n价格最高的产品：{', '.join(most_expensive_products)}")
print(f"最高价格：{max_price}元")