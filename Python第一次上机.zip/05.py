# 定义汇率
USD_TO_CNY = 6.868  # 1美元 = 6.868人民币
CNY_TO_USD = 0.1456  # 1人民币 = 0.1456美元

while True:
    input_str = input("请输入要兑换的货币币值，以$或￥结束：")
    currency_symbol = input_str[-1]
    amount = float(input_str[:-1])

    # 根据货币符号进行相应的转换
    if currency_symbol == '$':
        # 美元转换为人民币
        cny_amount = amount * USD_TO_CNY
        print(f"{amount}美元可以兑换人民币{cny_amount:.2f}元")
    elif currency_symbol == '￥':
        # 人民币转换为美元
        usd_amount = amount * CNY_TO_USD
        print(f"{amount}元人民币可以兑换{usd_amount:.2f}美元")
    else:
        print("货币符号错误，请使用$或￥")