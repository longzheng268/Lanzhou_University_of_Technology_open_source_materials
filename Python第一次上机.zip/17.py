def sum_of_digits(n):
    """
    计算正整数n的各位数字之和

    参数:
    n -- 正整数

    返回:
    各位数字之和
    """
    # 检查输入是否为正整数
    if not isinstance(n, int) or n <= 0:
        return "输入必须是一个正整数"

    # 方法一：使用字符串转换
    total = 0
    for digit in str(n):
        total += int(digit)

    return total


def sum_of_digits_math(n):
    """
    使用数学方法计算正整数n的各位数字之和

    参数:
    n -- 正整数

    返回:
    各位数字之和
    """
    # 检查输入是否为正整数
    if not isinstance(n, int) or n <= 0:
        return "输入必须是一个正整数"

    # 方法二：使用数学运算
    total = 0
    num = n
    while num > 0:
        total += num % 10  # 获取最后一位数字
        num //= 10  # 去掉最后一位数字

    return total


# 主程序测试函数
if __name__ == "__main__":
    print("正整数各位数字之和计算程序")
    print("=" * 40)

    # 测试用例
    test_numbers = [123, 4567, 98765, 100, 1, 999]

    print("测试用例：")
    for num in test_numbers:
        result1 = sum_of_digits(num)
        result2 = sum_of_digits_math(num)
        print(f"{num} 的各位数字之和: {result1} (方法一), {result2} (方法二)")

    print("\n" + "=" * 40)

    # 交互式测试
    while True:
        try:
            user_input = input("\n请输入一个正整数（输入 'q' 退出）: ")

            if user_input.lower() == 'q':
                print("程序已退出！")
                break

            num = int(user_input)

            if num <= 0:
                print("请输入一个正整数！")
                continue

            result1 = sum_of_digits(num)
            result2 = sum_of_digits_math(num)

            print(f"数字 {num} 的各位数字之和为: {result1}")

            # 显示计算过程
            digits = [int(d) for d in str(num)]
            calculation = " + ".join(str(d) for d in digits)
            print(f"计算过程: {calculation} = {result1}")

        except ValueError:
            print("输入无效，请输入一个正整数！")