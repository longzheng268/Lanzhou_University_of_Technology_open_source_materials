def is_perfect_number(n):
    """
    判断一个整数是否为完数

    参数:
    n -- 要判断的整数

    返回:
    如果是完数返回1，否则返回0
    """
    # 检查输入是否为正整数
    if not isinstance(n, int) or n <= 0:
        return 0

    # 特殊情况：1没有真因子，不是完数
    if n == 1:
        return 0

    # 计算所有真因子的和
    factors_sum = 0
    for i in range(1, n):
        if n % i == 0:
            factors_sum += i

    # 判断是否为完数
    if factors_sum == n:
        return 1
    else:
        return 0


def is_perfect_number_optimized(n):
    """
    优化版的完数判断函数

    参数:
    n -- 要判断的整数

    返回:
    如果是完数返回1，否则返回0
    """
    # 检查输入是否为正整数
    if not isinstance(n, int) or n <= 0:
        return 0

    # 特殊情况：1没有真因子，不是完数
    if n == 1:
        return 0

    # 优化：只需要检查到sqrt(n)
    factors_sum = 1  # 1是所有大于1的数的因子
    i = 2
    while i * i <= n:
        if n % i == 0:
            factors_sum += i
            if i != n // i:  # 避免重复添加平方根
                factors_sum += n // i
        i += 1

    # 判断是否为完数
    if factors_sum == n:
        return 1
    else:
        return 0


def find_perfect_numbers(limit):
    """
    查找指定范围内的所有完数

    参数:
    limit -- 查找的上限

    返回:
    完数列表
    """
    perfect_numbers = []
    for i in range(2, limit + 1):
        if is_perfect_number_optimized(i):
            perfect_numbers.append(i)
    return perfect_numbers


# 主程序
if __name__ == "__main__":
    print("完数判断程序")
    print("=" * 40)
    print("完数是指一个数恰好等于它的真因子之和的数")
    print("例如：6 = 1 + 2 + 3，所以6是完数")
    print()

    # 显示一些已知的完数
    known_perfects = [6, 28, 496, 8128]
    print(f"已知的完数有：{known_perfects}")
    print()

    # 交互式测试
    while True:
        try:
            user_input = input("请输入一个正整数（输入 'q' 退出）: ")

            if user_input.lower() == 'q':
                print("程序已退出！")
                break

            n = int(user_input)

            if n <= 0:
                print("请输入一个正整数！")
                continue

            # 判断是否为完数
            result = is_perfect_number(n)

            if result == 1:
                print(f"{n} 是完数")

                # 显示真因子和计算过程
                factors = []
                for i in range(1, n):
                    if n % i == 0:
                        factors.append(str(i))

                calculation = " + ".join(factors)
                print(f"计算过程: {calculation} = {n}")
            else:
                print(f"{n} 不是完数")

                # 显示真因子和
                factors = []
                for i in range(1, n):
                    if n % i == 0:
                        factors.append(str(i))

                if factors:
                    factors_sum = sum(int(f) for f in factors)
                    calculation = " + ".join(factors)
                    print(f"真因子和为: {calculation} = {factors_sum} ≠ {n}")
                else:
                    print(f"{n} 没有真因子")

            print()

        except ValueError:
            print("输入无效，请输入一个正整数！")

    # 查找一定范围内的完数
    print("\n" + "=" * 40)
    print("查找10000以内的完数：")
    perfects = find_perfect_numbers(10000)
    print(f"10000以内的完数有：{perfects}")