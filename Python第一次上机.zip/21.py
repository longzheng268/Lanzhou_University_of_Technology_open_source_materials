import re
from collections import Counter


def process_text_file(input_file, output_file):
    """
    处理文本文件，统计行数、单词总数和词频

    参数:
    input_file -- 输入文件名
    output_file -- 输出文件名
    """
    try:
        # 读取文件内容
        with open(input_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        # 统计行数
        line_count = len(lines)

        # 提取所有单词（转换为小写，去除标点）
        all_words = []
        for line in lines:
            # 使用正则表达式提取单词，忽略标点符号
            words = re.findall(r'\b[a-zA-Z]+\b', line)
            # 转换为小写并添加到列表
            all_words.extend([word.lower() for word in words])

        # 统计单词总数
        word_count = len(all_words)

        # 统计词频
        word_freq = Counter(all_words)

        # 按词频降序排序
        sorted_word_freq = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)

        # 写入统计结果到新文件
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("文件统计结果\n")
            f.write("=" * 50 + "\n")
            f.write(f"文件: {input_file}\n")
            f.write(f"行数: {line_count}\n")
            f.write(f"单词总数: {word_count}\n")
            f.write("\n词频统计:\n")
            f.write("-" * 30 + "\n")

            for word, freq in sorted_word_freq:
                f.write(f"{word}: {freq}\n")

        # 在控制台也输出结果
        print("统计完成！")
        print(f"输入文件: {input_file}")
        print(f"输出文件: {output_file}")
        print(f"行数: {line_count}")
        print(f"单词总数: {word_count}")
        print("\n前5个最常出现的单词:")
        for word, freq in sorted_word_freq[:5]:
            print(f"  {word}: {freq}")

        return line_count, word_count, sorted_word_freq

    except FileNotFoundError:
        print(f"错误: 找不到文件 {input_file}")
        return None, None, None
    except Exception as e:
        print(f"处理文件时出错: {e}")
        return None, None, None


def create_sample_file():
    """
    创建示例文件 zen.txt
    """
    content = """Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Complex is better than complicated."""

    with open('zen.txt', 'w', encoding='utf-8') as f:
        f.write(content)

    print("已创建示例文件 zen.txt")


# 主程序
if __name__ == "__main__":
    print("文本文件统计程序")
    print("=" * 50)

    # 输入和输出文件名
    input_file = "zen.txt"
    output_file = "zen1.txt"

    # 检查输入文件是否存在，如果不存在则创建示例文件
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            print(f"找到输入文件: {input_file}")
    except FileNotFoundError:
        print(f"未找到输入文件 {input_file}，正在创建示例文件...")
        create_sample_file()

    # 处理文件
    line_count, word_count, word_freq = process_text_file(input_file, output_file)

    if line_count is not None:
        print("\n" + "=" * 50)
        print("验证题目要求:")

        # 验证题目中提到的特定单词的词频
        better_count = 0
        simple_count = 0

        for word, freq in word_freq:
            if word == "better":
                better_count = freq
            if word == "simple":
                simple_count = freq

        print(f"better 的词频: {better_count}")
        print(f"simple 的词频: {simple_count}")

        # 显示文件内容
        print("\n原文件内容:")
        print("-" * 30)
        with open(input_file, 'r', encoding='utf-8') as f:
            content = f.read()
            print(content)

        print("\n统计结果已保存到:", output_file)

        # 显示统计文件内容
        print("\n统计文件内容:")
        print("-" * 30)
        with open(output_file, 'r', encoding='utf-8') as f:
            stats_content = f.read()
            print(stats_content)