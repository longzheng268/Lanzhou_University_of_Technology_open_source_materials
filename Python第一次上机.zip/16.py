# 定义旅游城市字典
dic_city = {
    "张三风": ["北京", "成都"],
    "李茉绸": ["上海", "广州", "兰州"],
    "慕容福": ["太原", "西安", "济南", "上海"]
}

print("旅游城市统计")
print("=" * 30)

# （1）统计每个人旅游过的城市的数目
print("（1）每个人旅游过的城市数目：")
print("-" * 30)
for person, cities in dic_city.items():
    city_count = len(cities)
    print(f"{person}去过{city_count}个城市")

# （2）统计去过上海的人数以及名单
print("\n（2）去过上海的人员统计：")
print("-" * 30)
shanghai_visitors = []
for person, cities in dic_city.items():
    if "上海" in cities:
        shanghai_visitors.append(person)

shanghai_count = len(shanghai_visitors)
if shanghai_count > 0:
    visitor_names = "、".join(shanghai_visitors)
    print(f"去过上海的有{shanghai_count}人，他们是{visitor_names}")
else:
    print("没有人去过上海")

# 额外功能：统计所有城市和热门城市
print("\n（3）额外统计信息：")
print("-" * 30)

# 统计所有去过的城市
all_cities = []
for cities in dic_city.values():
    all_cities.extend(cities)

# 统计每个城市被访问的次数
from collections import Counter
city_counts = Counter(all_cities)

print("各城市访问次数：")
for city, count in city_counts.items():
    print(f"{city}: {count}次")

# 找出最热门的城市
if city_counts:
    max_count = max(city_counts.values())
    popular_cities = [city for city, count in city_counts.items() if count == max_count]
    print(f"\n最热门的城市：{'、'.join(popular_cities)}（{max_count}次访问）")