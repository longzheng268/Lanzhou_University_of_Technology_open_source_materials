# 给定字符串
url = "www.moe.gov.cn"

print("原始字符串:", url)
print()

# （1）输出第一个字符
print("（1）第一个字符:", url[0])

# （2）输出前三个字符
print("（2）前三个字符:", url[0:3])

# （3）输出后三个字符
print("（3）后三个字符:", url[-3:])

# （4）输出字符串的总长度
print("（4）字符串总长度:", len(url))

# （5）输出字符'o'在字符串中第一个位置的索引值
print("（5）字符'o'第一个位置的索引:", url.index('o'))

# （6）输出字符'o'出现的总次数
print("（6）字符'o'出现的总次数:", url.count('o'))

# （7）将字符串中所有的"."替换为"-"并输出
url_replaced = url.replace('.', '-')
print("（7）替换'.'为'-':", url_replaced)

# （8）将字符串中所有的字母全部转换为大写字母并输出
url_upper = url.upper()
print("（8）转换为大写:", url_upper)

# （9）删除字符串中的标点符号，把字符串拆分为四个字符串
url_split = url.split('.')
print("（9）拆分后的字符串:", url_split)

print()
# 再次输出原始字符串，观察变化
print("再次输出原始字符串:", url)
print("原始字符串没有变化，因为字符串是不可变对象，所有操作都返回新字符串，不会修改原字符串。")