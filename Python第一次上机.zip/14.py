# 评委评分列表
lst_score = [9, 10, 8, 9, 10, 7, 6, 8, 7, 8]

print("原始评分列表：", lst_score)

# （1）使用sort()方法对列表进行升序排序
lst_score.sort()
print("排序后的评分列表：", lst_score)

# （2）去掉一个最高分（最后一个元素）
# 使用pop()方法删除最后一个元素
max_score = lst_score.pop()
print(f"去掉一个最高分：{max_score}")

# （3）去掉一个最低分（第一个元素）
# 使用pop(0)方法删除第一个元素
min_score = lst_score.pop(0)
print(f"去掉一个最低分：{min_score}")

print("去掉最高分和最低分后的评分列表：", lst_score)

# （4）计算最终得分（剩下8个分数的平均值）
final_score = sum(lst_score) / len(lst_score)
print(f"剩余{len(lst_score)}个分数的总和：{sum(lst_score)}")
print(f"该参赛选手的最终得分：{final_score:.2f}")