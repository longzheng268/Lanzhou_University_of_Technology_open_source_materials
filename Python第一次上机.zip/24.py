import networkx as nx
import matplotlib.pyplot as plt
import jieba
import re
from collections import defaultdict

# 添加自定义词典，确保人名被正确识别
jieba.add_word('张老师')
jieba.add_word('小梅')
jieba.add_word('小明')
jieba.add_word('小红')


def extract_people_from_sentence(sentence):
    """
    从单句话中提取人物
    """
    # 定义可能的人物名称
    people_names = ['张老师', '小梅', '小明', '小红']

    # 使用jieba分词
    words = jieba.lcut(sentence)

    # 提取在人物名称列表中的词
    found_people = [word for word in words if word in people_names]

    return found_people


def build_relationship_network(diary_text):
    """
    构建人物关系网络
    """
    # 分句 - 以句号、感叹号、问号分割
    sentences = re.split(r'[。！？]', diary_text)
    sentences = [s.strip() for s in sentences if s.strip()]

    # 存储人物共现关系
    relationship_counts = defaultdict(int)

    # 处理每个句子
    for sentence in sentences:
        # 提取该句子中的人物
        people_in_sentence = extract_people_from_sentence(sentence)

        # 如果句子中有多个人物，则建立他们之间的关系
        if len(people_in_sentence) > 1:
            # 为每对人物增加共现次数
            for i in range(len(people_in_sentence)):
                for j in range(i + 1, len(people_in_sentence)):
                    # 排序以确保 (A,B) 和 (B,A) 被视为相同
                    person1, person2 = sorted([people_in_sentence[i], people_in_sentence[j]])
                    relationship_counts[(person1, person2)] += 1

    return relationship_counts, sentences


def create_relationship_graph(relationship_counts):
    """
    创建人物关系图
    """
    # 创建无向图
    G = nx.Graph()

    # 添加节点和边
    for (person1, person2), count in relationship_counts.items():
        G.add_edge(person1, person2, weight=count)

    return G


def draw_relationship_graph(G, relationship_counts):
    """
    绘制人物关系图
    """
    # 设置图形大小
    plt.figure(figsize=(10, 8))

    # 定义节点位置
    pos = nx.spring_layout(G, k=1, iterations=50)

    # 提取边的权重
    edge_weights = [G[u][v]['weight'] for u, v in G.edges()]

    # 绘制节点
    nx.draw_networkx_nodes(G, pos, node_size=1500, node_color='lightblue', alpha=0.9)

    # 绘制边，宽度与权重成正比
    nx.draw_networkx_edges(G, pos, width=[w * 2 for w in edge_weights], alpha=0.7, edge_color='gray')

    # 绘制节点标签
    nx.draw_networkx_labels(G, pos, font_size=12, font_family='SimHei')

    # 绘制边标签（共现次数）
    edge_labels = {(u, v): d['weight'] for u, v, d in G.edges(data=True)}
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=10)

    # 设置标题
    plt.title("人物关系图", fontsize=16, fontfamily='SimHei')

    # 移除坐标轴
    plt.axis('off')

    # 显示图形
    plt.tight_layout()
    plt.show()


def print_relationship_analysis(relationship_counts, sentences):
    """
    打印关系分析结果
    """
    print("日记文本分析结果")
    print("=" * 50)

    print("\n句子分析:")
    for i, sentence in enumerate(sentences, 1):
        people = extract_people_from_sentence(sentence)
        print(f"句子{i}: {sentence}")
        print(f"  出现人物: {', '.join(people) if people else '无'}")

    print("\n人物共现关系统计:")
    print("-" * 30)
    for (person1, person2), count in sorted(relationship_counts.items()):
        print(f"({person1}, {person2}): {count}次")

    # 计算每个人物的出现次数
    person_appearances = defaultdict(int)
    for (person1, person2), count in relationship_counts.items():
        person_appearances[person1] += count
        person_appearances[person2] += count

    print("\n人物活跃度:")
    print("-" * 30)
    for person, count in sorted(person_appearances.items(), key=lambda x: x[1], reverse=True):
        print(f"{person}: {count}次共现")


# 主程序
if __name__ == "__main__":
    # 日记文本
    diary_text = "张老师单独给小梅讲了10道习题。小明问了张老师一个问题。小红上课开小差被张老师批评了。小明跟小红下课一起玩了。小梅、小红还有小明放学后一起打扫卫生了。"

    print("开始分析日记文本...")
    print("日记内容:", diary_text)
    print()

    # 构建关系网络
    relationship_counts, sentences = build_relationship_network(diary_text)

    # 打印分析结果
    print_relationship_analysis(relationship_counts, sentences)

    # 创建关系图
    G = create_relationship_graph(relationship_counts)

    # 绘制关系图
    print("\n正在绘制人物关系图...")
    draw_relationship_graph(G, relationship_counts)