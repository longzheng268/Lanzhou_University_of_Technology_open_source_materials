numbers = [i for i in range(1, 101) if i % 3 == 0 and i % 5 != 0]
print("使用列表推导式的结果：")
print(numbers)