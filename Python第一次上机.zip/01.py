score1 = float(input("请输入第一门功课的分数: "))

score2 = float(input("请输入第二门功课的分数: "))

score3 = float(input("请输入第三门功课的分数: "))

sum = score1 + score2 + score3

avg = sum / 3

print("三门功课的总分是:", sum)
print("三门功课的平均分是:", avg)