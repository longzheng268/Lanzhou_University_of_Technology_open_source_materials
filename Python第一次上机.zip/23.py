def replace_in_file(filename, old_text, new_text):
    """
    替换文件中的文本内容

    参数:
    filename -- 文件名
    old_text -- 要替换的旧文本
    new_text -- 替换后的新文本
    """
    try:
        # 读取文件内容
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()

        # 替换文本
        new_content = content.replace(old_text, new_text)

        # 将替换后的内容写回文件
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(new_content)

        print(f"成功将文件中的 '{old_text}' 替换为 '{new_text}'")

        # 返回替换前后的内容用于显示
        return content, new_content

    except FileNotFoundError:
        print(f"错误: 找不到文件 {filename}")
        return None, None
    except Exception as e:
        print(f"处理文件时出错: {e}")
        return None, None


def create_sample_file():
    """
    创建示例文件 Wenjian.txt
    """
    content = "Hello World"

    with open('Wenjian.txt', 'w', encoding='utf-8') as f:
        f.write(content)

    print("已创建示例文件 Wenjian.txt")


# 主程序
if __name__ == "__main__":
    print("文件内容替换程序")
    print("=" * 40)

    # 文件名和替换内容
    filename = "Wenjian.txt"
    old_text = "World"
    new_text = "Python"

    # 检查文件是否存在，如果不存在则创建示例文件
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            original_content = f.read()
            print(f"找到文件: {filename}")
            print(f"原文件内容: {original_content}")
    except FileNotFoundError:
        print(f"未找到文件 {filename}，正在创建示例文件...")
        create_sample_file()
        with open(filename, 'r', encoding='utf-8') as f:
            original_content = f.read()
            print(f"原文件内容: {original_content}")

    print("\n" + "=" * 40)

    # 执行替换操作
    old_content, new_content = replace_in_file(filename, old_text, new_text)

    if old_content and new_content:
        print("\n替换详情:")
        print(f"替换前: {old_content}")
        print(f"替换后: {new_content}")

        # 验证替换结果
        print("\n验证文件当前内容:")
        print("-" * 30)
        with open(filename, 'r', encoding='utf-8') as f:
            current_content = f.read()
            print(current_content)