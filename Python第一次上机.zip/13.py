# 初始学生列表
lst_student = [["001", "李梅", 19], ["002", "刘祥", 20], ["003", "张武", 18]]

print("初始学生列表：")
for student in lst_student:
    print(student)

# （1）在列表末尾添加学生信息
print("\n（1）在列表末尾添加学生信息：")
lst_student.append(["004", "刘宁", 20])
lst_student.append(["006", "梁峰", 19])
print("添加后的学生列表：")
for student in lst_student:
    print(student)

# （2）在列表的适当位置添加学生信息
print("\n（2）在适当位置添加学生信息（005号学生）：")
# 找到004号学生的位置，然后在其后插入
for i, student in enumerate(lst_student):
    if student[0] == "004":
        lst_student.insert(i + 1, ["005", "林歌", 20])
        break
print("插入后的学生列表：")
for student in lst_student:
    print(student)

# （3）输出学号为003的学生信息
print("\n（3）学号为003的学生信息：")
for student in lst_student:
    if student[0] == "003":
        print(f"学号：{student[0]}，姓名：{student[1]}，年龄：{student[2]}")
        break

# （4）输出所有学生的姓名
print("\n（4）所有学生的姓名：")
names = [student[1] for student in lst_student]
print("学生姓名：", ", ".join(names))

# （5）输出年龄大于19的所有学生的信息
print("\n（5）年龄大于19的所有学生信息：")
print("年龄大于19的学生：")
for student in lst_student:
    if student[2] > 19:
        print(f"学号：{student[0]}，姓名：{student[1]}，年龄：{student[2]}")