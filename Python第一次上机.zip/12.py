month_days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

print("月份天数查询系统")
print("请输入1-12查询对应月份的天数，输入0退出程序")

while True:
    try:
        # 获取用户输入的月份
        month = int(input("\n请输入月份（1-12，输入0退出）："))

        # 当用户输入月份为0时，循环结束
        if month == 0:
            print("程序已退出，谢谢使用！")
            break

        # 检查月份是否在有效范围内
        if month < 1 or month > 12:
            print("输入错误！月份应该在1-12之间")
            continue

        days = month_days[month - 1]
        print(f"{month}月份有{days}天")

    except ValueError:
        print("输入错误！请输入一个整数")