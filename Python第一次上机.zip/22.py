def process_poem_file(input_file, output_file):
    """
    读取文本文件，将多行内容合并为一行，并写入新文件

    参数:
    input_file -- 输入文件名
    output_file -- 输出文件名
    """
    try:
        # 读取文件内容
        with open(input_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        # 去除每行的换行符和首尾空格
        cleaned_lines = [line.strip() for line in lines]

        # 将多行内容合并为一行（用空格分隔）
        single_line = ' '.join(cleaned_lines)

        # 在控制台显示合并后的内容
        print("合并后的内容:")
        print(single_line)

        # 将合并后的内容写入新文件
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(single_line)

        print(f"\n内容已成功写入文件: {output_file}")

        return single_line, len(lines)

    except FileNotFoundError:
        print(f"错误: 找不到文件 {input_file}")
        return None, None
    except Exception as e:
        print(f"处理文件时出错: {e}")
        return None, None


def create_sample_file():
    """
    创建示例文件 yzy.txt
    """
    content = """慈母手中线，游子身上衣。
临行密密缝，意恐迟迟归。
谁言寸草心，报得三春晖。"""

    with open('yzy.txt', 'w', encoding='utf-8') as f:
        f.write(content)

    print("已创建示例文件 yzy.txt")


# 主程序
if __name__ == "__main__":
    print("文本文件处理程序")
    print("=" * 50)
    print("将多行文本合并为一行并写入新文件")
    print()

    # 输入和输出文件名
    input_file = "yzy.txt"
    output_file = "yzy2.txt"  # 严格按照题目要求

    # 检查输入文件是否存在，如果不存在则创建示例文件
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            print(f"找到输入文件: {input_file}")
            print("\n原文件内容:")
            print("-" * 30)
            content = f.read()
            print(content)
    except FileNotFoundError:
        print(f"未找到输入文件 {input_file}，正在创建示例文件...")
        create_sample_file()

        # 重新读取并显示文件内容
        with open(input_file, 'r', encoding='utf-8') as f:
            print("\n原文件内容:")
            print("-" * 30)
            content = f.read()
            print(content)

    print("\n" + "=" * 50)

    # 处理文件
    single_line, line_count = process_poem_file(input_file, output_file)

    if single_line is not None:
        print(f"\n处理完成!")
        print(f"原文件行数: {line_count}")
        print(f"合并后字符数: {len(single_line)}")

        # 验证输出文件内容
        print(f"\n验证输出文件 {output_file} 的内容:")
        print("-" * 40)
        with open(output_file, 'r', encoding='utf-8') as f:
            output_content = f.read()
            print(output_content)