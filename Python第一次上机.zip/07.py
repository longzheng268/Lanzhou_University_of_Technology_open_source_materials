import math

# 输入三角形的三条边长
a = float(input("请输入第一条边长："))
b = float(input("请输入第二条边长："))
c = float(input("请输入第三条边长："))

# 判断是否可以构成三角形
if a > 0 and b > 0 and c > 0 and (a + b > c) and (a + c > b) and (b + c > a):
    # 计算周长
    perimeter = a + b + c

    # 计算半周长
    h = perimeter / 2

    # 计算面积（使用海伦公式）
    area = math.sqrt(h * (h - a) * (h - b) * (h - c))

    # 输出结果，保留一位小数
    print(f"三角形的周长为：{perimeter:.1f}")
    print(f"三角形的面积为：{area:.1f}")
else:
    print("输入的边长无法构成三角形")